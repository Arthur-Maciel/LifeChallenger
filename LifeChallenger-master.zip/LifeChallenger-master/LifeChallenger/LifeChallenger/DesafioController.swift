//
//  DesafioController.swift
//  LifeChallenger
//
//  Created by student on 05/11/18.
//  Copyright © 2018 student. All rights reserved.
//

import Foundation
import UIKit
//fazer a mesma coisa dos materiais, baseado na resposta escolhida, colocar a descrição correta

class DesafioController : UIViewController {
    @IBOutlet weak var textoDescricao: UITextView!
    var titulo : String?
}
