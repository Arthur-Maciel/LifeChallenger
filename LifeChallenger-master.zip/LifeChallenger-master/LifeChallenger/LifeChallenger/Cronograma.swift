//
//  Cronograma.swift
//  LifeChallenger
//
//  Created by student on 06/11/18.
//  Copyright © 2018 student. All rights reserved.
//

import Foundation
import UIKit

class Cronograma : UIViewController{
    
    @IBOutlet weak var imagemTreino: UIImageView!
}
