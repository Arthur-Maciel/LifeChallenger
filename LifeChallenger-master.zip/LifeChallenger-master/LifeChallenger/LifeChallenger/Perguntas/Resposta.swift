//
//  Resposta.swift
//  LifeChallenger
//
//  Created by student on 05/11/18.
//  Copyright © 2018 student. All rights reserved.
//

import Foundation

class Resposta {
    var resposta: String
    var peso: Int
    
    init (resposta: String, peso: Int) {
        self.resposta = resposta
        self.peso = peso
    }
}
