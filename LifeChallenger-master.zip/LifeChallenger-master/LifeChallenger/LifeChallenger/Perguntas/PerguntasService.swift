//
//  PerguntasService.swift
//  LifeChallenger
//
//  Created by Henrique Urruth on 05/11/18.
//  Copyright © 2018 student. All rights reserved.
//

import Foundation

class PerguntasService{
//    var perguntas : [Pergunta] = [];
//    init() {
//        var respostas : [Resposta] = [];
//        respostas.append(Resposta(resposta:"Sim", peso: 5))
//        respostas.append(Resposta(resposta: "Não", peso: 3))
//        
//        perguntas.append(Pergunta(pergunta: "Você já corre?", respostas: respostas))
//        perguntas.append(Pergunta(pergunta: "Você já caminha na rua como exercício?", respostas: respostas))
//        perguntas.append(Pergunta(pergunta: "Você malha?", respostas: respostas))
//    }
//    
//    func getPerguntas() -> [Pergunta]{
//        return perguntas
//    }
}
